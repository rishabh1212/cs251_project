#include<iostream>
using namespace std;
int main(){cout<<"dfgdf"<<endl;return 0;}
